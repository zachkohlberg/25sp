import java.awt.event.MouseEvent;

public class DraggableBall extends Ball {
    private double mousePrevX, mousePrevY;

    public DraggableBall(Scene.Actions actions) {
        super(actions);
    }

    @Override
    public void mousePressed(MouseEvent e) {
        mousePrevX = e.getX();
        mousePrevY = e.getY();
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        double dx = e.getX() - mousePrevX;
        double dy = e.getY() - mousePrevY;

        setPosition(getX() + dx, getY() + dy);

        mousePrevX = e.getX();
        mousePrevY = e.getY();
    }
}
