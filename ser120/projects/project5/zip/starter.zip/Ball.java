import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.util.Random;

public class Ball {
    private Scene.Actions actions;
    private double x, y, radius;
    private Color color;

    public Ball(Scene.Actions actions) {
        this.actions = actions;

        Random rand = new Random();

        radius = rand.nextDouble(10, 50);
        x = rand.nextDouble(radius, actions.getWidth() - radius);
        y = rand.nextDouble(radius, actions.getHeight() - radius);
        color = new Color(rand.nextInt(0, 0x1000000));
    }

    public void draw(Graphics g) {
        g.setColor(color);
        g.fillOval((int) (x - radius), (int) (y - radius), (int) (radius * 2), (int) (radius * 2));
    }

    public boolean contains(double x, double y) {
        double dx = this.x - x;
        double dy = this.y - y;
        // squaring the radius is cheaper than taking a square root
        return radius * radius > dx * dx + dy * dy;
    }

    public void update() {
    }

    public void mousePressed(MouseEvent e) {
    }

    public void mouseReleased(MouseEvent e) {
    }

    public void mouseDragged(MouseEvent e) {
    }

    // the rest is just getters and setters, nothing interesting

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        // "this." isn't necessary, but it makes it clearer what's going on
        setPosition(x, this.y);
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        // "this." isn't necessary, but it makes it clearer what's going on
        setPosition(this.x, y);
    }

    public void setPosition(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public Scene.Actions getActions() {
        return actions;
    }
}
