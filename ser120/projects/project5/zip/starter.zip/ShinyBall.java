import java.awt.Color;

public class ShinyBall extends Ball {
    public ShinyBall(Scene.Actions actions) {
        super(actions);
    }

    @Override
    public void update() {
        Color c = getColor();
        float[] hsb = Color.RGBtoHSB(c.getRed(), c.getGreen(), c.getBlue(), null);
        hsb[0] = (hsb[0] + 0.005f) % 1f;
        setColor(Color.getHSBColor(hsb[0], hsb[1], hsb[2]));
    }
}
