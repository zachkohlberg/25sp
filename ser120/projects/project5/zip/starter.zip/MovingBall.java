import java.util.Random;

public class MovingBall extends Ball {
    private double vx, vy;

    public MovingBall(Scene.Actions actions) {
        super(actions);

        Random rand = new Random();

        double direction = rand.nextDouble(0, Math.TAU);
        double speed = rand.nextDouble(0.5, 5.0);
        vx = speed * Math.cos(direction);
        vy = speed * -Math.sin(direction);
    }

    @Override
    public void update() {
        setPosition(getX() + vx, getY() + vy);

        if (getX() < getRadius() || getX() + getRadius() > getActions().getWidth()) {
            vx = -vx;
        }
        if (getY() < getRadius() || getY() + getRadius() > getActions().getHeight()) {
            vy = -vy;
        }
    }
}
