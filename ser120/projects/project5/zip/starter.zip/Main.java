import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

public class Main {
    private JFrame frame;
    private JPanel dp, bp;
    private JButton shiny, draggable, moving, splitting;
    private Scene scene;
    private Timer timer;

    public Main() {
        scene = new Scene(800, 800);

        dp = new JPanel() {
            @Override
            public void paintComponent(Graphics g) {
                super.paintComponent(g);

                scene.draw(g);
            }
        };
        dp.setPreferredSize(new Dimension(scene.getWidth(), scene.getHeight()));
        dp.setBackground(Color.BLACK);
        scene.registerMouseListener(dp);

        shiny = new JButton("Shiny");
        shiny.addActionListener(_ -> scene.getActions().addToScene(new ShinyBall(scene.getActions())));
        draggable = new JButton("Draggable");
        draggable.addActionListener(_ -> scene.getActions().addToScene(new DraggableBall(scene.getActions())));
        moving = new JButton("Moving");
        moving.addActionListener(_ -> scene.getActions().addToScene(new MovingBall(scene.getActions())));
        splitting = new JButton("Splitting");
        splitting.addActionListener(_ -> scene.getActions().addToScene(new SplittingBall(scene.getActions())));

        bp = new JPanel();
        bp.setBackground(Color.GRAY);
        bp.add(shiny);
        bp.add(draggable);
        bp.add(moving);
        bp.add(splitting);

        frame = new JFrame();
        frame.add(dp, BorderLayout.CENTER);
        frame.add(bp, BorderLayout.SOUTH);
        frame.setVisible(true);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        timer = new Timer(16, _ -> {
            scene.update();
            dp.repaint();
        });
        timer.start();
    }

    public static void main(String[] args) {
        new Main();
    }
}
