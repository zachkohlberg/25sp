import java.awt.event.MouseEvent;

public class SplittingBall extends MovingBall {
    public SplittingBall(Scene.Actions actions) {
        super(actions);
    }

    @Override
    public void mousePressed(MouseEvent e) {
        if (getRadius() > 20) {
            createChild();
            createChild();
        }
        getActions().removeFromScene(this);
    }

    private void createChild() {
        Ball child = new SplittingBall(getActions());
        child.setColor(getColor());
        child.setRadius(getRadius() / 2);
        child.setPosition(getX(), getY());
        getActions().addToScene(child);
    }
}
