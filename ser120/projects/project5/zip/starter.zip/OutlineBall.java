import java.awt.Color;
import java.awt.Graphics;

public class OutlineBall extends Ball {
    public OutlineBall(Scene.Actions actions) {
        super(actions);
    }

    @Override
    public void draw(Graphics g) {
        super.draw(g);

        g.setColor(Color.BLACK);
        g.drawOval((int) (getX() - getRadius()), (int) (getY() - getRadius()), (int) (getRadius() * 2),
                (int) (getRadius() * 2));
    }
}
